import "./Footer.css";
export default function Footer(){
    return(
        <footer>
            <p>&copy; Copyright Maple Leaf Wellness, 2024</p>
        </footer>
    )
}