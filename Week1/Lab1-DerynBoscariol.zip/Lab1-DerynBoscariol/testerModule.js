import {addFruit, countFruit} from "./myFirstModule.js";

addFruit("mangoes");
countFruit();
