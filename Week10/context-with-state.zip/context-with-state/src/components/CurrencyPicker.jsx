export default function CurrencyPicker() {
  return (
    <div>
      <button>CA</button>
      <button>US</button>
    </div>
  );
}