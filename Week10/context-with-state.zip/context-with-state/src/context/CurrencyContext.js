import {createContext} from "react";

export const CurrencyContext = createContext();