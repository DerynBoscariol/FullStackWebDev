export default function Header() {
  
  return(
    <header id="header">
      <h2 className="site-name">
        <a href="/">True or False?</a>
      </h2>
    </header>
  )
}