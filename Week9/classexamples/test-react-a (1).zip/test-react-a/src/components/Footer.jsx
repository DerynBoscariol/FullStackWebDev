export default function Footer() {
  return(
    <footer id="footer">
      <p>&copy; Copyright HTTP5222, 2024.</p>
    </footer>
  )
}